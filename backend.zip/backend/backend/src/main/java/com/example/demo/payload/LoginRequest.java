package com.example.demo.payload;

import org.springframework.security.core.Authentication;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@AllArgsConstructor  @NoArgsConstructor
public class LoginRequest {
@Id
private String name;
private String password;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Authentication getEmail() {
	// TODO Auto-generated method stub
	return null;
}
}
