package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Users;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UsersService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UsersServiceImpl implements UsersService, UserDetailsService{


    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;
    
    public UsersServiceImpl(UserRepository userRepo, PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }
	@Override
	public Users saveUsers(Users user) {
		user.setPassword(passwordEncoder.encode(user.getPassword())); //encrypt password
		return userRepo.save(user);
	}

	@Override
	public Users getUsersById(Long id) {
		
		return userRepo.findById(id)
				.orElseThrow(() -> new RuntimeException("User not found"));
	}

	@Override
	public List<Users> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public Users updateUsers(Long id, Users user) {
		Users existing = getUsersById(id);

        existing.setName(user.getName());
        existing.setEmail(user.getEmail());
        existing.setRole(user.getRole());
        
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            existing.setPassword(passwordEncoder.encode(user.getPassword()));
        }
		return userRepo.save(existing);
	}

	@Override
	public void deleteUsers(Long id) {
		userRepo.deleteById(id);
		
	}

	@Override
	public Users loadUserByEmail(String email) {
		return userRepo.findByEmail(email)
				.orElseThrow(() -> new UsernameNotFoundException("User Email Not Found"));
	}

	@Override
	public UserDetails loadUserByUsername(String email) {
		Users user = loadUserByEmail(email);
		
		return User.builder()
				.username(user.getEmail())
				.password(user.getPassword())
		        .roles(user.getRole())
		        .build();
	}

}

