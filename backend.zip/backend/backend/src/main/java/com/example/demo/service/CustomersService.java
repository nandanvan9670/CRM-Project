package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Customers;

public interface CustomersService {


		Customers createCustomers(Customers customer);
		
		Customers getCustomersById(Long id);
		
		List<Customers> getAllCustomers();
		
	    Customers updateCustomer(Long id, Customers customer);

	    void deleteCustomers(Long id);
	}
