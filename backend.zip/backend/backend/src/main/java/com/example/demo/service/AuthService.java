package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import lombok.RequiredArgsConstructor;
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthService {
	
private final AuthenticationManager authenticationManager = null;

private final UsersService usersService = null;

 private final UserRepository userRepository = null; 

private final PasswordEncoder passwordEncoder = null;

private final JwtUtils jwtUtils = new JwtUtils();

//public AuthController(AuthenticationManager authenticationManager, UsersService usersService, UserRepository userRepo, PasswordEncoder passwordEncoder, JwtUtils jwtUtils) {
//    this.authenticationManager = authenticationManager;
//    this.userRepository = userRepo;
//    this.usersService = usersService;
//    this.passwordEncoder = passwordEncoder;
//    this.jwtUtils = jwtUtils;
//}

@PostMapping("/register")
public ResponseEntity<Users> register(@RequestBody RegisterRequest req) {
    Users user = new Users();
    user.setName(req.getName());
    user.setEmail(req.getEmail());
    user.setPassword(passwordEncoder.encode(req.getPassword()));
    user.setRole(req.getRole());
    
    Users savedUser = usersService.saveUsers(user);

    return ResponseEntity.ok(savedUser);
    //return usersService.saveUsers(user);
}

@PostMapping("/login")
public ResponseEntity<JwtResponse> login(@RequestBody LoginRequest req) {

	Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword())
    );
   
    String jwt = jwtUtils.generateJwtToken(authentication);

    String email = authentication.getName();
    Users user = (Users) authentication.getPrincipal();

    JwtResponse response=new JwtResponse(
    		jwt,
    		user.getId(),
    		user.getName(),
    		user.getEmail(),
    		user.getRole()
    		);
    
    return ResponseEntity.ok(response);
}
}