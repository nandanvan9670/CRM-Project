package com.example.demo.controller;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Users;
import com.example.demo.jwt.JwtUtils;
import com.example.demo.payload.JwtResponse;
import com.example.demo.payload.LoginRequest;
import com.example.demo.payload.RegisterRequest;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UsersService;

import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
	
private  final AuthenticationManager authenticationManager;

private final UsersService usersService;

 private final UserRepository userRepository; 

private final PasswordEncoder passwordEncoder;

private final JwtUtils jwtUtils;

public AuthController(AuthenticationManager authenticationManager, UsersService usersService, UserRepository userRepo, PasswordEncoder passwordEncoder, JwtUtils jwtUtils) {
    this.authenticationManager = authenticationManager;
    this.userRepository = userRepo;
    this.usersService = usersService;
    this.passwordEncoder = passwordEncoder;
    this.jwtUtils = jwtUtils;
}
//public AuthController(AuthenticationManager authenticationManager,
//        UsersService usersService,
//        UserRepository userRepository,
//        PasswordEncoder passwordEncoder,
//        JwtUtils jwtUtils) {

@PostMapping("/register")
public Users register(@RequestBody RegisterRequest req) {
    Users user = new Users();
    user.setName(req.getName());
    user.setEmail(req.getEmail());
    user.setPassword(passwordEncoder.encode(req.getPassword()));
    user.setRole(req.getRole());

    return usersService.saveUsers(user);
}

@PostMapping("/login")
public JwtResponse login(@RequestBody LoginRequest req) {

    authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword())
    );

    String token = jwtUtils.generateJwtToken(req.getEmail());

    return new JwtResponse();
}

}
