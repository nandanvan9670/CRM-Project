package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Users;



public interface UsersService {
	
	Users saveUsers(Users user);
	
	Users getUsersById(Long id);
	
	List<Users> getAllUsers();
	
	Users updateUsers(Long id, Users user);
	
	void deleteUsers(Long id);
	
	Users loadUserByEmail(String email);
}
