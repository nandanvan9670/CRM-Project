package com.example.demo.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Customers;
import com.example.demo.service.CustomersService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomersService service = null;

    @PostMapping
    public Customers create(@RequestBody Customers c) {
        return service.createCustomers(c);
    }

    @GetMapping
    public List<Customers> getAll() {
        return service.getAllCustomers();
    }

    @GetMapping("/{id}")
    public Customers getById(@PathVariable Long id) {
        return service.getCustomersById(id);
    }

    @PutMapping("/{id}")
    public Customers update(@PathVariable Long id, @RequestBody Customers c) {
        return service.updateCustomer(id, c);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteCustomers(id);
        return "Deleted successfully";
    }
}
