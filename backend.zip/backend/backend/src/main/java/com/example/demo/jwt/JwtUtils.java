package com.example.demo.jwt;

import java.security.Key;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

public class JwtUtils {
	  @Value("${app.jwtSecret}")
	    private String jwtSecret;

	    @Value("${app.jwtExpirationMs}")
	    private int jwtExpirationMs;

	    private Key getSigningKey() {
	        return Keys.hmacShaKeyFor(jwtSecret.getBytes());
	    }

	    public String generateJwtToken(Authentication authentication) {
	        String username = authentication.getName();
	        Date date = new Date();
	        Date expiry = new Date(date.getTime() + jwtExpirationMs);
	        return Jwts.builder()
	                .setSubject(username)
	                .claim("role","role")
	                .setIssuedAt(date)
	                .setExpiration(expiry)
	                .signWith(getSigningKey(),SignatureAlgorithm.HS256)
	                .compact();
	    }
	    public String getUsernameFromJwt(String token) {
	        return Jwts.parserBuilder().setSigningKey(getSigningKey()).build()
	                .parseClaimsJws(token).getBody().getSubject();
	    }

	    public boolean validateJwtToken(String token) {
	        try {
	            Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
	            return true;
	        } catch (JwtException | IllegalArgumentException e) {
	            return false;
	        }
	    }
}